Basic Cobol stuff just for lols.

You can compile programs using open-cobol etc.

"cobc -x filename"
